import React, { useEffect, useState } from 'react';
import styles from './Quizes.module.css';
import { getQuiz } from '../../service/firebase';

function Quizes() {
  let quizData = null;
  const [quizindex, setIndex] = useState(0);

  async function getQuizData() {
    quizData = await getQuiz();
    console.log(quizData);
    console.log(quizData[quizindex]);
  }

  useEffect(() => {
    getQuizData();
  }, []);

  return (
    <section className={styles.section}>
      {quizData && (
        <div>
          <h2> {quizData[quizindex].qeustion}</h2>
        </div>
      )}
    </section>
  );
}

export default Quizes;
